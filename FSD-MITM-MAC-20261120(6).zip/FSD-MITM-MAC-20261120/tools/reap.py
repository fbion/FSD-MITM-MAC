#!/usr/bin/env python3
"""tools/reap.py — 按「解释器 + 安装目录」精确清理本环境所有进程（macOS 版新增）

为什么要有它：
  * `pgrep -f "arp_mitm.py"` 会匹配到**任何命令行里含这个字符串**的进程
    —— 包括正在执行 `grep arp_mitm.py` 的 shell、开着该文件的编辑器、甚至
    调用 fsdctl 的宿主进程。原 Windows 包 stop_api_intercept.ps1 里就踩过
    （注释里写了要排除 pwsh/cmd/DSH），Mac 版必须把它做扎实。
  * 清理判据改成：**命令行的第一个 token 是本环境的解释器**（venv python /
    mitmdump / Python.framework 里的 Python），**并且**含有本安装目录的绝对路径。
    这样编辑器、shell、grep 一律不会被误杀。
  * 同时排除自身与全部祖先进程，避免"自己把自己杀掉"。

用法：
    python tools/reap.py                 # 发 SIGTERM，3 秒后对残留发 SIGKILL
    python tools/reap.py --dry-run       # 只列出会杀谁
    python tools/reap.py --sig TERM      # 只发 TERM，不升级
    python tools/reap.py --grace 5
退出码：0 = 清干净了；1 = 仍有残留
"""
from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = str(Path(__file__).resolve().parent.parent)

# 本环境允许被杀的解释器特征（命令行第一个 token 的 basename 或前缀）
INTERP_HINTS = ("python", "python3", "python3.13", "python3.12", "mitmdump", "mitmproxy")
# 这些脚本是本环境的组成部分：命令行里必须出现 $ROOT/<name>
SCRIPTS = (
    "fsd_mock.py", "dns_sink.py", "svc/stack.py", "tools/arp_mitm.py",
    "tools/supervise_all.py", "tools/daemonize.py", "web/fsd_panel.py", "web/server.py",
)


def ps_table() -> list[tuple[int, int, str]]:
    out = subprocess.run(["ps", "-axo", "pid=,ppid=,command="],
                         capture_output=True, text=True, errors="replace").stdout
    rows = []
    for line in out.splitlines():
        parts = line.strip().split(None, 2)
        if len(parts) < 3:
            continue
        try:
            rows.append((int(parts[0]), int(parts[1]), parts[2]))
        except ValueError:
            continue
    return rows


def ancestors(table: list[tuple[int, int, str]]) -> set[int]:
    parent = {pid: ppid for pid, ppid, _ in table}
    out = {os.getpid()}
    cur = os.getpid()
    for _ in range(64):
        cur = parent.get(cur, 0)
        if not cur or cur in out:
            break
        out.add(cur)
    return out


def is_ours(pid: int, cmd: str, root: str) -> bool:
    if root not in cmd:
        return False
    tok = cmd.strip().split(None, 1)
    if not tok:
        return False
    first = tok[0]
    base = os.path.basename(first)
    if not (first.endswith("/MacOS/Python") or any(base.startswith(h) for h in INTERP_HINTS)):
        return False
    return any(f"{root}/{s}" in cmd for s in SCRIPTS)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=ROOT)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--sig", default="TERM")
    ap.add_argument("--grace", type=float, default=3.0)
    args = ap.parse_args()
    root = args.root.rstrip("/")

    table = ps_table()
    skip = ancestors(table)
    targets = [(pid, cmd) for pid, _ppid, cmd in table
               if pid not in skip and is_ours(pid, cmd, root)]

    if not targets:
        print("没有本环境的残留进程")
        return 0

    print(f"目标 {len(targets)} 个进程：")
    for pid, cmd in targets:
        print(f"  {pid:>7}  {' '.join(cmd.split()[:3])[:110]}")

    if args.dry_run:
        print("（--dry-run：不发信号）")
        return 0

    sig = getattr(signal, f"SIG{args.sig.upper()}", signal.SIGTERM)
    for pid, _ in targets:
        try:
            os.kill(pid, sig)
        except ProcessLookupError:
            pass
        except PermissionError:
            print(f"  权限不足：{pid}（请用 root 跑）")
    if sig != signal.SIGTERM:
        return 0

    deadline = time.time() + args.grace
    left = []
    while time.time() < deadline:
        time.sleep(0.25)
        alive = {pid for pid, _ppid, cmd in ps_table() if pid in {p for p, _ in targets}}
        left = sorted(alive)
        if not left:
            break

    if left:
        print(f"{args.grace:g}s 后仍有 {len(left)} 个没退：{left} → SIGKILL")
        for pid in left:
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except PermissionError:
                print(f"  权限不足：{pid}（请用 root 跑）")
        time.sleep(0.5)
        alive = {pid for pid, _ppid, _cmd in ps_table()} & set(left)
        if alive:
            print(f"仍存活：{sorted(alive)}")
            return 1
    print("清理完成")
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""tools/selftest.py — 自测：走本机代理打一次 /feature_configuration

macOS 版做了三件事（Windows 版只会对 282B 硬编码校验，换载荷就误报）：

  1) **功能**：经代理请求 api-prd…/feature_configuration，核对
     body 字节数 == payload.json 压缩后长度、md5 == X-Checksum 头。
  2) **链路**：取服务端叶证书，核对 issuer 是 mitmproxy --emudhra 的
     EM OV TLS CA - G3C，并用 cryptography 验证**签名真的对得上**
     （本地不需要、也无法信任 emSign 根 —— 那是车机的信任库干的事）。
  3) **可选严格模式** `--anchor <pem>`：用给定 PEM 作为信任锚做完整
     TLS 校验（例如把 certs2/device-trust-EMOV-G3C.pem 装到设备上时）。

用法：
  python tools/selftest.py                          # 默认打 8080
  SELFTEST_PORT=8080 python tools/selftest.py
  python tools/selftest.py --host api-prd.vn.cloud.tesla.cn --anchor certs2/device-trust-EMOV-G3C.pem
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import socket
import ssl
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

try:
    import fsdconfig  # noqa: E402
    _CFG = fsdconfig.load()
except Exception:  # noqa: BLE001
    _CFG = {}

DEFAULT_HOST = "api-prd.vn.cloud.tesla.cn"


def expected_body() -> tuple[bytes, str]:
    p = os.environ.get("FSD_MOCK_JSON", os.path.join(ROOT, "payload.json"))
    with open(p, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return body, hashlib.md5(body).hexdigest()


def connect(port: int, host: str):
    raw = socket.create_connection(("127.0.0.1", port), timeout=10)
    raw.sendall(f"CONNECT {host}:443 HTTP/1.1\r\nHost: {host}:443\r\n\r\n".encode())
    buf = b""
    while b"\r\n\r\n" not in buf:
        chunk = raw.recv(4096)
        if not chunk:
            break
        buf += chunk
    print("proxy:", buf.split(b"\r\n")[0].decode(errors="replace"))
    if b" 200 " not in buf.split(b"\r\n")[0]:
        raise SystemExit("代理没建立隧道（8080 上跑的是 mitmproxy 吗？）")
    return raw


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=int(os.environ.get("SELFTEST_PORT", _CFG.get("port_proxy") or 8080)))
    ap.add_argument("--host", default=os.environ.get("SELFTEST_HOST", DEFAULT_HOST))
    ap.add_argument("--anchor", default=os.environ.get("SELFTEST_CAFILE", ""),
                    help="信任锚 PEM；给了就做完整 TLS 校验")
    args = ap.parse_args()

    body_expected, md5_expected = expected_body()
    print(f"期望 payload: {len(body_expected)} 字节 / md5 {md5_expected}")

    raw = connect(args.port, args.host)
    if args.anchor:
        ctx = ssl.create_default_context(cafile=args.anchor)
        ctx.check_hostname = True
        ctx.verify_mode = ssl.CERT_REQUIRED
        print(f"严格模式：信任锚 {args.anchor}")
    else:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        print("链路模式：不校验信任（车机侧才需要），只核对签发关系与载荷")
    tls = ctx.wrap_socket(raw, server_hostname=args.host)
    print("tls ok:", tls.version(), "| cipher:", tls.cipher()[0])

    # ---------- 证书签发关系 ----------
    chain_ok = None
    try:
        import mitmproxy.certs as mc
        from cryptography import x509
        der = tls.getpeercert(binary_form=True)
        leaf = x509.load_der_x509_certificate(der)
        emov = x509.load_pem_x509_certificates(mc.EMUDHRA_CHAIN_PEM)[0]
        print("leaf subject:", leaf.subject.rfc4514_string())
        print("leaf issuer :", leaf.issuer.rfc4514_string())
        print("emudhra CA  :", emov.subject.rfc4514_string())
        issuer_match = leaf.issuer.rfc4514_string() == emov.subject.rfc4514_string()
        try:
            leaf.verify_directly_issued_by(emov)
            sig_ok = True
        except Exception as exc:  # noqa: BLE001
            sig_ok = False
            print("  签名校验失败:", type(exc).__name__, exc)
        chain_ok = issuer_match and sig_ok
        print("issuer 匹配:", issuer_match, "| 签名有效:", sig_ok)
    except Exception as exc:  # noqa: BLE001
        print("（跳过签发关系检查:", type(exc).__name__, exc, "）")

    # ---------- 请求 ----------
    path = "/mothership/vehicles/TESTVIN/feature_configuration"
    tls.sendall(f"GET {path} HTTP/1.1\r\nHost: {args.host}\r\nUser-Agent: fsd-selftest\r\n"
                f"Connection: close\r\n\r\n".encode())
    resp = b""
    while True:
        chunk = tls.recv(65535)
        if not chunk:
            break
        resp += chunk
    head, _, body = resp.partition(b"\r\n\r\n")
    print(head.decode(errors="replace"))
    body_md5 = hashlib.md5(body).hexdigest()
    print(f"body bytes: {len(body)}  md5: {body_md5}")

    ok_size = len(body) == len(body_expected)
    ok_md5 = body_md5 == md5_expected
    ok_hdr = f"X-Checksum: {body_md5}".encode() in head
    print("size match:", ok_size, "| md5 match:", ok_md5, "| X-Checksum 正确:", ok_hdr)
    if not ok_size:
        print("body:", body[:300].decode(errors="replace"))

    ok = ok_size and ok_md5 and ok_hdr and (chain_ok is not False)
    print("RESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

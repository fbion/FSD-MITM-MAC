#!/usr/bin/env python3
"""tools/daemonize.py — 把命令扔进新会话后台跑（macOS 版刚需）

为什么需要它：
  * macOS 没有 `setsid` 命令；
  * BSD 的 `nohup` 在没有控制终端时会直接报
    `nohup: can't detach from console: No such process` 然后不启动进程
    —— 用 `osascript ... with administrator privileges` / launchd / ssh 免登录
    起的 root 环境就是这种"没有 tty"的情况；
  * 子进程必须脱离父进程的会话，否则 `do shell script` 收尾时会连带杀掉它。

用法：
    python tools/daemonize.py <日志文件> -- <命令> [参数...]

stdout/stderr 一起追加到日志文件；打印子进程 pid 后立刻退出。
"""
from __future__ import annotations

import os
import signal
import subprocess
import sys


SIGS = (signal.SIGTERM, signal.SIGHUP, signal.SIGINT, signal.SIGQUIT)


def reset_signals() -> None:
    """把 SIGTERM/SIGHUP/SIGINT 复位成默认动作**并**从屏蔽字里解除，再 fork 子进程。

    为什么必须两件都做（macOS 上实测）：
      * AppleScript 的 `do shell script`、某些 launchd 上下文会把 SIGTERM 设成 SIG_IGN；
      * 且/或把它放进信号屏蔽字（sigprocmask）。
      exec 不会清"被忽略"的处置，也**不会清屏蔽字** —— 两者都会被子进程继承。
      结果是 `fsdctl stop` 发 TERM 后进程既不死也不退出：TERM 挂在 pending 里，
      只有 SIGKILL 能收场（原先 stop 就一直在 escalate 到 KILL）。
    """
    for sig in SIGS:
        try:
            signal.signal(sig, signal.SIG_DFL)
        except (ValueError, OSError, AttributeError):
            pass
    try:
        signal.pthread_sigmask(signal.SIG_UNBLOCK, set(SIGS))
    except (AttributeError, OSError, ValueError):
        pass


def main() -> int:
    if len(sys.argv) < 4 or "--" not in sys.argv:
        print("用法: daemonize.py <日志文件> -- <命令> [参数...]", file=sys.stderr)
        return 2
    reset_signals()
    sep = sys.argv.index("--")
    logpath = sys.argv[1]
    argv = sys.argv[sep + 1:]
    if not argv:
        print("daemonize.py: 缺少要执行的命令", file=sys.stderr)
        return 2
    parent = os.path.dirname(os.path.abspath(logpath))
    if parent:
        os.makedirs(parent, exist_ok=True)
    fh = open(logpath, "ab", buffering=0)
    fh.write(f"\n===== {__import__('time').strftime('%Y-%m-%d %H:%M:%S')} daemonize: {' '.join(argv)} =====\n".encode())
    proc = subprocess.Popen(
        argv,
        stdin=subprocess.DEVNULL,
        stdout=fh,
        stderr=subprocess.STDOUT,
        start_new_session=True,   # setsid：脱离当前会话/进程组
        close_fds=True,
        cwd=os.environ.get("FSD_DAEMON_CWD") or None,
    )
    print(proc.pid)
    return 0


if __name__ == "__main__":
    sys.exit(main())

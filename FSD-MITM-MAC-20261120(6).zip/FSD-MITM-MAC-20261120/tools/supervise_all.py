#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""supervise_all.py — 全套组件看门狗（macOS 版）

  组件                 存活判据              复活动作
  常驻栈 stack.py       4567 在监听            svc/stack.py
  443 拦截 mitmdump     443 在监听             mitmdump（反向 api-prd + fsd_mock）
  ARP 引流 arp_mitm     日志 120s 内有更新     tools/arp_mitm.py
  看板 fsd_panel        8900 在监听            web/fsd_panel.py

每 30 秒一轮，日志 logs/supervise.log

与 Windows 版的差异：
  * ROOT/BIN 全部按本文件位置推导，不再写死 C:\\fsd-mitm
  * 车机 IP / 网关 / 网卡 / 端口全部来自 config.json（fsdconfig）
  * 不再用 pythonw/CREATE_NO_WINDOW：launchd 或 setsid 下本来就没有窗口
  * 443 需要 root；非 root 时只跳过 443 与 ARP，仍能把栈和看板拉起来
"""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import signal
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import fsdconfig  # noqa: E402

BIN = Path(sys.executable).parent
PY = Path(sys.executable)
MITMDUMP = BIN / "mitmdump"
LOGS = ROOT / "logs"
LOG = LOGS / "supervise.log"
ARP_LOG = LOGS / "arp_mitm.log"
INTERVAL = 30

LOGS.mkdir(parents=True, exist_ok=True)


def reset_signals() -> None:
    """SIGTERM/SIGHUP 复位为默认动作并从屏蔽字解除：避免继承 SIG_IGN/屏蔽后"停不掉"。"""
    _sigs = (signal.SIGTERM, signal.SIGHUP, signal.SIGINT, signal.SIGQUIT)
    for _sig in _sigs:
        try:
            signal.signal(_sig, signal.SIG_DFL)
        except (ValueError, OSError, AttributeError):
            pass
    try:
        signal.pthread_sigmask(signal.SIG_UNBLOCK, set(_sigs))
    except (AttributeError, OSError, ValueError):
        pass


def log(msg: str) -> None:
    line = "%s %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def port_open(port: int) -> bool:
    s = socket.socket()
    s.settimeout(0.6)
    try:
        s.connect(("127.0.0.1", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def child_env() -> dict:
    env = dict(os.environ)
    env.update({
        "FSD_MOCK_LOG_DIR": str(LOGS),
        "FSD_MOCK_JSON": str(ROOT / "payload.json"),
        "FSD_MOCK_LOG_ALL": "1",
        "FSD_MOCK_MODE_FILE": str(ROOT / "mode.json"),
        "PYTHONUNBUFFERED": "1",
    })
    return env


def spawn(argv: list[str], name: str = "spawn") -> None:
    fh = open(LOGS / f"{name}.log", "ab", buffering=0)
    subprocess.Popen(argv, cwd=str(ROOT), env=child_env(), start_new_session=True,
                     stdin=subprocess.DEVNULL, stdout=fh, stderr=subprocess.STDOUT)


def main() -> None:
    reset_signals()
    cfg = fsdconfig.load()
    log(f"supervisor start | root={ROOT} | iface={cfg.get('iface')} target={cfg.get('target')}")
    while True:
        try:
            if not port_open(int(cfg["port_reverse"])):
                log("4567 未监听 -> 启动常驻栈")
                spawn([str(PY), str(ROOT / "svc" / "stack.py")], "stack")
                time.sleep(8)

            fresh = False
            try:
                fresh = (time.time() - os.path.getmtime(ARP_LOG)) < 120
            except OSError:
                fresh = False
            if not fresh and os.geteuid() == 0:
                log("ARP 引流停止 -> 重启")
                spawn([str(PY), str(ROOT / "tools" / "arp_mitm.py"),
                       "--target", str(cfg.get("target") or ""),
                       "--gateway", str(cfg.get("gateway") or ""),
                       "--our-ip", str(cfg.get("our_ip") or ""),
                       "--answer", str(cfg.get("answer") or ""),
                       "--iface", str(cfg.get("iface") or "en0"),
                       "--duration", str(cfg.get("duration") or 0),
                       "--rst-dst", str(cfg.get("rst_dst") or "")], "arp")
                time.sleep(8)

            if not port_open(int(cfg["port_api"])):
                if os.geteuid() == 0:
                    log("443 未监听 -> 启动拦截实例")
                    spawn([str(MITMDUMP), "-s", str(ROOT / "fsd_mock.py"),
                           "--set", "confdir=" + str(ROOT / str(cfg["confdir"])),
                           "--set", "ssl_insecure=true",
                           "--set", "connection_strategy=lazy",
                           "--set", "block_global=false", "--emudhra",
                           "--mode", f"reverse:https://api-prd.vn.cloud.tesla.cn@{cfg['port_api']}"],
                          "mitm443")
                    time.sleep(10)
                else:
                    log("443 未监听，但当前不是 root -> 跳过（sudo bin/fsdctl start）")

            if not port_open(int(cfg["port_panel"])):
                log("8900 未监听 -> 启动看板")
                spawn([str(PY), str(ROOT / "web" / "fsd_panel.py"), "--port", str(cfg["port_panel"])], "panel")
                time.sleep(5)
        except Exception as exc:  # noqa: BLE001
            log("supervisor error: %r" % (exc,))
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()

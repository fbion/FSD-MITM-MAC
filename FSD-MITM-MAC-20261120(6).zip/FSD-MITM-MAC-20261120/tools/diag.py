#!/usr/bin/env python3
"""tools/diag.py — 一次性诊断报告（贴给别人看就够定位问题）

    python tools/diag.py            # 全文
    python tools/diag.py --short    # 只给结论 + 最近请求

回答四个问题：
  1. 车机到底有没有连到我们（DNS 劫持 / ARP / 443 握手）
  2. 它请求了哪些 host / path（关键是 feature_configuration 有没有出现）
  3. 为什么没命中（mode=observe？路径不对？只有探活没有真实流量？）
  4. 载荷与端口当前是什么状态
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
LOGS = ROOT / "logs"


def load_jsonl(path: Path, limit: int = 200000) -> list[dict]:
    rows: list[dict] = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for i, line in enumerate(fh):
                if i > limit:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except ValueError:
                    continue
    except OSError:
        pass
    return rows


def cfg() -> dict:
    try:
        import fsdconfig
        return fsdconfig.load()
    except Exception:  # noqa: BLE001
        return {}


def listeners() -> dict[int, str]:
    out: dict[int, str] = {}
    try:
        raw = subprocess.run(["lsof", "-nP", "-iTCP", "-sTCP:LISTEN"],
                             capture_output=True, text=True, timeout=8).stdout
        for line in raw.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 9:
                port = parts[8].rsplit(":", 1)[-1]
                out.setdefault(int(port) if port.isdigit() else 0, f"{parts[0]} pid={parts[1]}")
    except Exception:  # noqa: BLE001
        pass
    return out


def normclient(c) -> str:
    """'('192.168.0.9', 5512)' -> '192.168.0.9'"""
    if not c:
        return "-"
    s = str(c).strip("()")
    return s.split(",")[0].strip("'\" ")


def is_loopback(ip: str) -> bool:
    return ip in ("127.0.0.1", "::1", "localhost", "-", "")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--short", action="store_true")
    ap.add_argument("--n", type=int, default=15)
    args = ap.parse_args()

    c = cfg()
    hits = load_jsonl(LOGS / "hits.jsonl")
    dns = load_jsonl(LOGS / "dns.jsonl")
    hs = load_jsonl(LOGS / "handshake.log")

    kinds = Counter(r.get("kind") for r in hits)
    host_path = Counter()
    for r in hits:
        url = r.get("url") or ""
        body = url.split("://", 1)[-1]
        host, _, path = body.partition("/")
        host_path[(host, "/" + path)] += 1

    feat = [r for r in hits if "feature_configuration" in (r.get("url") or "")]
    feat_hit = [r for r in feat if r.get("kind") == "HIT"]
    car_feat = [r for r in feat if not is_loopback(normclient(r.get("client")))]
    car_any = [r for r in hits if not is_loopback(normclient(r.get("client")))]
    dns_car = [r for r in dns if not is_loopback(str(r.get("peer", "")))]

    hs_ok = [r for r in hs if r.get("event") == "handshake_ok"]
    hs_fail = [r for r in hs if r.get("event") == "handshake_failed"]
    hs_probe = [r for r in hs if r.get("event") == "probe_non_tls"]
    hs_ok_car = [r for r in hs_ok if not is_loopback(normclient(r.get("client")))]
    hs_fail_car = [r for r in hs_fail if not is_loopback(normclient(r.get("client")))]

    ls = listeners()
    payload = ROOT / "payload.json"
    try:
        pb = payload.read_bytes()
        pj = json.loads(pb)
        import hashlib
        p_sig = f"{len(pb)} B / md5 {hashlib.md5(pb).hexdigest()[:12]} / {len(pj)} 字段"
    except Exception:  # noqa: BLE001
        p_sig = "读不到 payload.json"
    try:
        mode = json.loads((ROOT / "mode.json").read_text(encoding="utf-8")).get("mode", "reply")
    except Exception:  # noqa: BLE001
        mode = "?"

    print("=" * 66)
    print(f"FSD 诊断报告  {datetime.now():%Y-%m-%d %H:%M:%S}   root={ROOT}")
    print("=" * 66)
    print(f"配置   iface={c.get('iface')} target={c.get('target') or '(空)'} "
          f"gateway={c.get('gateway') or '(空)'} answer={c.get('answer') or '(空)'}")
    print(f"载荷   {p_sig}   模式 mode={mode}")
    ports = [c.get("port_dns", 53), c.get("port_reverse", 4567), c.get("port_proxy", 8080),
             c.get("port_api", 443), c.get("port_panel", 8900), c.get("port_legacy", 8899)]
    print("监听   " + "  ".join(f"{p}:{'UP' if p in ls else 'down'}" for p in ports))

    print("-" * 66)
    print(f"命中   HIT={kinds.get('HIT',0)}  OBSERVE={kinds.get('OBSERVE',0)}  "
          f"FLOW={kinds.get('FLOW',0)}  NEAR_MISS={kinds.get('NEAR_MISS',0)}")
    print(f"非回环(车机侧)请求 {len(car_any)} 条 / 其中 feature_configuration {len(car_feat)} 条；"
          f"回环(自测)命中 {len(feat_hit)} 条")
    print(f"DNS   重定向 {len(dns)} 条，其中来自车机网段 {len(dns_car)} 条")
    print(f"TLS   成功 {len(hs_ok)}（车机侧 {len(hs_ok_car)}）  "
          f"真失败 {len(hs_fail)}（车机侧 {len(hs_fail_car)}）  非TLS探活 {len(hs_probe)}")

    if not args.short:
        print("-" * 66)
        print("最近请求（host / path / client）:")
        for r in hits[-args.n:]:
            print(f"  {(r.get('ts') or '')[11:19]} {r.get('kind','?'):9} "
                  f"{(r.get('client') or '-'):22} {(r.get('url') or '')[:78]}")
        print("出现过的 host+path（次数递减）:")
        for (h, p), n in host_path.most_common(12):
            print(f"  {n:5}  {h}{p[:70]}")
        if hs_fail:
            print("最近的握手失败（真实 ClientHello）:")
            for r in hs_fail[-5:]:
                print(f"  {(r.get('ts') or '')[11:19]} {normclient(r.get('client')):22} "
                      f"sni={r.get('sni') or '-'} err={r.get('error')}")
        if dns:
            print("最近的 DNS 查询:")
            for r in dns[-6:]:
                print(f"  {(r.get('ts') or '')[11:19]} {r.get('q'):38} {r.get('action'):9} "
                      f"-> {r.get('ip') or '-'}  peer={r.get('peer')}")

    print("=" * 66)
    verdict: list[str] = []
    if not hs_ok and not car_any:
        verdict.append("车机侧一条流量都没到：先查接入拓扑（车机是否真的走这台 Mac）")
    if car_any and not car_feat:
        verdict.append("车机流量到了，但**从没请求过 feature_configuration** —— "
                       "不是拦截坏了，是车机还没到拉配置的时机（重启车机 / 切换 Wi-Fi / 等下一次轮询）")
    if car_feat and not feat_hit:
        if mode == "observe":
            verdict.append("mode=observe：只记录不回包，改成 fsdctl mode reply")
        else:
            verdict.append("车机请求到了却没命中：看最近的 FLOW 里那条 URL 是不是 "
                           "/feature_configuration（带 VIN 的路径才算）")
    if hs_fail_car:
        verdict.append(f"有 {len(hs_fail_car)} 次**车机侧**握手失败 —— 多半是它不信任 "
                       "emSign 链（需要把 device-trust-EMOV-G3C 装到被拦设备上）")
    if hs_probe:
        verdict.append(f"{len(hs_probe)} 条“握手失败”其实是非 TLS 探活（本机 nc/curl 探端口），可以忽略")
    if not verdict:
        verdict.append("看起来正常：等车机下一次请求，命中会写进 logs/hits.jsonl")
    for v in verdict:
        print("结论 · " + v)
    print("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""局域网发现：UDP 触发 ARP + 读取邻居表，找车机（macOS 版）。

用法:
    python tools/lan_scan.py            # 按 config.json 的网段扫
    python tools/lan_scan.py 192.168.1
    sudo python tools/lan_scan.py       # 有时需要 root 才能刷满邻居表
"""
import json
import os
import re
import socket
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
try:
    import fsdconfig
    _CFG = fsdconfig.load()
except Exception:  # noqa: BLE001
    _CFG = {}

if len(sys.argv) > 1:
    prefix = sys.argv[1]
else:
    base = _CFG.get("our_ip") or "192.168.1.1"
    prefix = ".".join(str(base).split(".")[:3])
DARWIN = sys.platform == "darwin"

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
for i in range(1, 255):
    try:
        s.sendto(b"\x00", (f"{prefix}.{i}", 9))
    except OSError:
        pass
s.close()
time.sleep(1.2)

out = subprocess.run(["arp", "-an"] if DARWIN else ["arp", "-a"],
                     capture_output=True, text=True, errors="replace").stdout
rows = []
if DARWIN:
    pat = re.compile(r"\((\d+\.\d+\.\d+\.\d+)\)\s+at\s+([0-9a-fA-F:]{11,17})\s+on\s+(\S+)")
    for m in pat.finditer(out):
        if m.group(1).startswith(prefix + "."):
            mac = "-".join(f"{int(x, 16):02x}" for x in m.group(2).split(":"))
            rows.append((m.group(1), mac, m.group(3)))
else:
    pat = re.compile(r"\s*(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F-]{17})\s+(\S+)")
    for m in pat.finditer(out):
        if m.group(1).startswith(prefix + "."):
            rows.append((m.group(1), m.group(2).lower(), m.group(3)))

for ip, mac, kind in sorted(rows, key=lambda r: int(r[0].split(".")[-1])):
    pa = ["ping", "-c", "1", "-W", "500", "-q", ip] if DARWIN else ["ping", "-n", "1", "-w", "500", ip]
    p2 = subprocess.run(pa, capture_output=True, text=True)
    alive = p2.returncode == 0
    print(f"{ip:16} {mac}  {kind:8} {'alive' if alive else 'no-reply'}")
print(f"-- {len(rows)} 台设备（网段 {prefix}.0/24）")

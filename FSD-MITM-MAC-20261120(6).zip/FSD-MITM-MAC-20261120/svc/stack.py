"""svc/stack.py — 常驻守护：DNS sink + mitmproxy reverse(4567) + proxy(8080) + 旧看板(8899)

macOS 版与 Windows 版的差异：
  * 解释器/命令一律取自当前 venv（sys.executable），不再写死 venv\\Scripts\\*.exe
  * 没有 CREATE_NEW_PROCESS_GROUP / CREATE_NO_WINDOW，改用 start_new_session=True
    （所以本进程被 Ctrl-C 打断时子进程不受影响，仍由本守护/看门狗管理）
  * UDP 53 需要 root：不是 root 时只记一条日志并跳过 DNS（其余照跑）
  * 所有 IP/网卡/端口从 config.json 读（见 app/fsdconfig.py）

启动：
  sudo ~/fsd-mitm/venv/bin/python ~/fsd-mitm/svc/stack.py
"""
from __future__ import annotations

import json
import os
import socket
import struct
import subprocess
import sys
import signal
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import fsdconfig  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
PY = Path(sys.executable)
BIN = PY.parent
DUMP = BIN / "mitmdump"
LOGS = ROOT / "logs"
PAYLOAD = ROOT / "payload.json"
ADDON = ROOT / "fsd_mock.py"
IGNORE = r"^(hermes-prd|hermes-stream-prd|telemetry-prd)\.vn\.cloud\.tesla\.cn(?::\d+)?$"

CFG = fsdconfig.load()
DNS_PORT = int(CFG["port_dns"])
CONFDIR = ROOT / str(CFG["confdir"])
DNS_HEALTH_NAME = f"{uuid.uuid4().hex}.fsd-dns.invalid"

LOGS.mkdir(parents=True, exist_ok=True)
proc: dict[str, subprocess.Popen] = {}

# 单实例锁（与 Windows 版同一个思路：只允许一份守护）
LOCK_PORT = 45799
_lock_sock: socket.socket | None = None


def acquire_single_instance() -> bool:
    global _lock_sock
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", LOCK_PORT))
        s.listen(1)
    except OSError:
        s.close()
        return False
    _lock_sock = s
    return True


def reset_signals() -> None:
    """SIGTERM/SIGHUP 复位为默认动作并从屏蔽字解除：避免继承 SIG_IGN/屏蔽后"停不掉"。"""
    _sigs = (signal.SIGTERM, signal.SIGHUP, signal.SIGINT, signal.SIGQUIT)
    for _sig in _sigs:
        try:
            signal.signal(_sig, signal.SIG_DFL)
        except (ValueError, OSError, AttributeError):
            pass
    try:
        signal.pthread_sigmask(signal.SIG_UNBLOCK, set(_sigs))
    except (AttributeError, OSError, ValueError):
        pass


def log(msg: str) -> None:
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, flush=True)
    try:
        with open(LOGS / "stack.log", "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def local_ip() -> str:
    """本机在"车机那张网卡"上的 IP：优先 config.our_ip，否则按 iface 探测。"""
    if CFG.get("our_ip"):
        return str(CFG["our_ip"])
    iface = CFG.get("iface") or "en0"
    try:
        out = subprocess.run(["ipconfig", "getifaddr", iface], capture_output=True, text=True, timeout=3)
        ip = (out.stdout or "").strip()
        if ip:
            return ip
    except Exception:  # noqa: BLE001
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("223.5.5.5", 53))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


def tcp_open(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.25):
            return True
    except OSError:
        return False


def udp_open(port: int) -> bool:
    """反证法判断 UDP 是否被占（macOS 上 SO_REUSEADDR 会误判，这里不开复用）。"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.bind(("0.0.0.0", port))
        return False
    except OSError:
        return True
    finally:
        s.close()


def spawn(name: str, argv: list[str], env_extra: dict | None = None) -> None:
    env = dict(os.environ)
    env["PYTHONUNBUFFERED"] = "1"
    env["FSD_MOCK_LOG_DIR"] = str(LOGS)
    env["FSD_MOCK_JSON"] = str(PAYLOAD)
    env["FSD_MOCK_LOG_ALL"] = "1"
    env["FSD_MOCK_MODE_FILE"] = str(ROOT / "mode.json")
    if env_extra:
        env.update(env_extra)
    fh = open(LOGS / f"{name}.log", "ab", buffering=0)
    fh.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} start {name} =====\n".encode())
    p = subprocess.Popen(argv, stdout=fh, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                         env=env, cwd=str(ROOT), start_new_session=True)
    proc[name] = p
    log(f"started {name} pid={p.pid}")


def common_mitm() -> list[str]:
    return ["-s", str(ADDON), "--set", f"confdir={CONFDIR}", "--set", "ssl_insecure=true",
            "--set", "connection_strategy=lazy", "--set", "block_global=false",
            "--ignore-hosts", IGNORE, "--emudhra"]


LAST_IP: dict[str, str | None] = {"ip": None}


def dns_responding(ip: str) -> bool:
    transaction = int.from_bytes(os.urandom(2), "big")
    labels = [label.encode("ascii") for label in DNS_HEALTH_NAME.split(".")]
    question = b"".join(bytes([len(label)]) + label for label in labels) + b"\x00\x00\x01\x00\x01"
    query = struct.pack("!6H", transaction, 0x0100, 1, 0, 0, 0) + question
    expected = (
        struct.pack("!6H", transaction, 0x8180, 1, 1, 0, 0)
        + question
        + b"\xc0\x0c"
        + struct.pack("!HHIH", 1, 1, 60, 4)
        + socket.inet_aton(ip)
    )
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(0.25)
            sock.connect(("127.0.0.1", DNS_PORT))
            sock.send(query)
            return sock.recv(4096) == expected
    except OSError:
        return False


def ensure_dns(ip: str) -> str:
    if "dns" in proc:
        return "listening" if dns_responding(ip) else "not_responding"
    if os.geteuid() != 0 and DNS_PORT < 1024:
        return "need_root"
    if udp_open(DNS_PORT):
        return "port_in_use"
    argv = [str(PY), str(ROOT / "dns_sink.py"), "--ip", ip, "--port", str(DNS_PORT),
            "--upstream", str(CFG["upstream_dns"])]
    for d in CFG["redirect"]:
        argv += ["--redirect", d]
    spawn("dns", argv, env_extra={"FSD_DNS_HEALTH_NAME": DNS_HEALTH_NAME})
    return "starting"


def ensure(ip: str) -> str:
    for name, child in list(proc.items()):
        if child.poll() is not None:
            log(f"{name} exited rc={child.returncode}")
            proc.pop(name)

    if LAST_IP["ip"] and LAST_IP["ip"] != ip:
        log(f"local ip changed {LAST_IP['ip']} -> {ip} | restarting dns sink")
        old = proc.pop("dns", None)
        if old is not None:
            try:
                old.terminate()
                old.wait(timeout=5)
            except Exception:  # noqa: BLE001
                pass
        time.sleep(1)
    LAST_IP["ip"] = ip

    dns_status = ensure_dns(ip)

    if not tcp_open(int(CFG["port_reverse"])):
        spawn("reverse", [str(DUMP), *common_mitm(), "--mode", f"reverse:http://{CFG.get('reverse_upstream') or '192.0.2.1'}:4567",
                          "--listen-host", "0.0.0.0", "--listen-port", str(CFG["port_reverse"]),
                          "--set", "keep_host_header=true"])

    if not tcp_open(int(CFG["port_proxy"])):
        spawn("proxy", [str(DUMP), *common_mitm(), "--mode", f"regular@{CFG['port_proxy']}",
                        "--listen-host", "0.0.0.0"])

    if not tcp_open(int(CFG["port_legacy"])):
        spawn("web", [str(PY), str(ROOT / "web" / "server.py"), "--port", str(CFG["port_legacy"])])

    return dns_status


def main() -> None:
    reset_signals()
    if not acquire_single_instance():
        log("another stack.py instance is already running; exiting (single-instance lock)")
        return
    ip = local_ip()
    log(f"stack up | iface={CFG.get('iface')} local ip={ip} | dns->{ip} | "
        f"reverse={CFG['port_reverse']} | proxy={CFG['port_proxy']} | confdir={CONFDIR.name}")
    previous_dns_status = None
    while True:
        try:
            ip = local_ip()
            dns_status = ensure(ip)
            if dns_status != previous_dns_status:
                if dns_status == "port_in_use":
                    log(f"UDP {DNS_PORT} is unavailable; project DNS has not started")
                elif dns_status == "need_root":
                    log(f"UDP {DNS_PORT} needs root -> run: sudo ~/fsd-mitm/bin/fsdctl start")
                elif dns_status == "not_responding":
                    log("Project DNS did not answer its local health check")
            previous_dns_status = dns_status
            with open(LOGS / "stack_state.json", "w", encoding="utf-8") as fh:
                json.dump({"ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
                           "iface": CFG.get("iface"),
                           "ip": ip,
                           "tcp4567": tcp_open(int(CFG["port_reverse"])),
                           "tcp8080": tcp_open(int(CFG["port_proxy"])),
                           "udp53": dns_status == "listening",
                           "dns_status": dns_status,
                           "children": {k: v.pid for k, v in proc.items()}}, fh, ensure_ascii=False)
        except Exception as exc:  # noqa: BLE001
            log(f"ensure error: {type(exc).__name__}: {exc}")
        time.sleep(8)


if __name__ == "__main__":
    main()

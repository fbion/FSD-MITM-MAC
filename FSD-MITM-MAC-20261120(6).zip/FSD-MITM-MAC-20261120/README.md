# FSD 拦截环境 · macOS 版（CLEAN-2026 移植）

> 来源：`CLEAN-2026.zip` → `FSD-MITM-STANDALONE-CLEAN-20261119`（Windows 10/11 + PowerShell 那套）
> 本包是**同一套程序的 macOS 可运行版**：Python 部分原样保留（mitmproxy 12.3.1 插件、
> DNS sink、ARP 投毒、看板、看门狗），PowerShell 编排全部改写成 bash + launchd，
> 写死的 `C:\fsd-mitm` 与 `venv\Scripts\*.exe` 换成 `~/fsd-mitm` 与 `venv/bin/*`，
> 车机 IP / 网关 / 网卡 / 端口统一收口到 `config.json`。

装好就能跑的命令（实测通过）：

```bash
~/fsd-mitm/bin/fsdctl doctor     # 体检
~/fsd-mitm/bin/fsdctl start      # 起全套（要一次 sudo）
~/fsd-mitm/bin/fsdctl status
~/fsd-mitm/bin/fsdctl selftest   # 本机自测：拦截 + 载荷 + 签发关系
~/fsd-mitm/bin/fsdctl stop       # 全停（会先还原车机 ARP）
```

---

## 1. 安装

**要求**：macOS 13+（Apple Silicon / Intel 均可）· Python **3.12 或 3.13**（Homebrew 装，系统自带 3.9 不行）· 有网。

```bash
cd FSD-MITM-MAC-20261120
./install.sh              # 装到 ~/fsd-mitm，建 venv，装依赖，自动探测网卡/网关
./install.sh --check      # 只体检：列出本机网卡和地址，不动任何文件
./install.sh --start      # 装完直接起（要 sudo）
./install.sh --mirror     # pip 走清华源
./install.sh --home ~/fsd # 换安装目录（不推荐：路径按 ~/fsd-mitm 写文档）
./install.sh --force      # 已有部署时强制覆盖程序（logs/venv/config/payload 保留不动）
```

装完目录（与 Windows 的 `C:\fsd-mitm` 一一对应）：

```
~/fsd-mitm/
├─ bin/fsdctl                ← 唯一入口（= start_all.ps1 + stop_fsd_all.ps1 + stop_api_intercept.ps1
│                              + fw.ps1 + hosts.ps1 + ca.ps1 + web.ps1 的合并版）
├─ config.json               ← ★ 本机所有网络参数（新增：Windows 版散在 4 个脚本里）
├─ fsd_mock.py               ← mitmproxy 插件：命中 /feature_configuration 即短路回包
├─ payload.json              ← ★ 当前下发载荷（602 B / 20 字段，热加载）
├─ payload-16f.json / payload-282b.json   ← 回滚样本
├─ mode.json                 ← {"mode":"reply"|"observe"}
├─ dns_sink.py               ← 指定域名 → 本机
├─ svc/stack.py              ← 常驻栈：DNS 53 + reverse 4567 + proxy 8080 + 旧看板 8899
├─ tools/arp_mitm.py         ← ARP 投毒 + DNS 应答 + 二层转发 + RST 黑洞
├─ tools/supervise_all.py    ← 看门狗（30 s 巡检）
├─ tools/selftest.py         ← 自测（载荷 + 签发关系）
├─ tools/daemonize.py        ← 后台化启动器（macOS 没有 setsid，BSD nohup 在无 tty 时会坏）
├─ tools/reap.py             ← 按"解释器 + 安装目录"精确清场，绝不误杀 shell/编辑器
├─ tools/lan_scan.py         ← 局域网找车机
├─ web/fsd_panel.py          ← 8900 主看板（纯服务端渲染，0 JS）
├─ web/server.py             ← 8899 旧看板
├─ certs/ certs2/ certs3/    ← 三套 CA（certs2 = 命中时用的 --emudhra G3C 那套）
├─ logs/                     ← 全量日志 + 证据（hits.jsonl / requests/*.bin / handshake.log）
├─ venv/                     ← 自建虚拟环境（mitmproxy 12.3.1 / scapy 2.8.0 / flask 3.1.3）
└─ doc/win/                  ← 原 Windows 包文档（含 HANDOVER 坑清单，值得一读）
```

---

## 2. Windows → macOS 逐项对照

| Windows 包 | macOS 版 | 说明 |
|---|---|---|
| `一键安装.cmd` / `install.ps1`（7 步） | `install.sh`（7 步） | 去掉 UAC/注册表/桌面快捷方式；换成 venv + launchd（可选）+ 钥匙串 |
| `start_all.ps1` / `start_all.cmd` | `bin/fsdctl start` | 幂等；自动 sudo |
| `start_all.ps1 -Status`（9 项） | `bin/fsdctl status` | 同 9 项：栈/代理/旧看板/443/8900/DNS/ARP/看门狗/自启/CA |
| `stop_fsd_all.ps1` | `bin/fsdctl stop` | 先停看门狗，再 TERM ARP（触发还原），最后兜底释放端口 |
| `stop_api_intercept.ps1` | `bin/fsdctl stop-api` | 停 443 + 用 `--no-api` 重启引流 |
| `fw.ps1`（netsh 防火墙规则） | `bin/fsdctl pf` | macOS 没有按端口放行：ALF 按程序放行，本方案也不需要 pf rdr |
| `hosts.ps1`（ipconfig /flushdns） | `bin/fsdctl hosts add\|remove\|show` | `/etc/hosts` + `dscacheutil -flushcache` + `killall -HUP mDNSResponder` |
| `ca.ps1`（导出设备证书） | `bin/fsdctl ca install\|uninstall\|export\|list` | 多了「装进本机钥匙串」和「卸载」 |
| `web.ps1` | `bin/fsdctl`（panel 由 start 拉起） | — |
| `hotspot.ps1`（Windows 移动热点 + ICS） | **系统设置 → 通用 → 共享 → 互联网共享** | macOS 不允许脚本开关共享；`fsdctl` 只读状态，见第 4 节 |
| HKCU\...\Run 自启 | `sudo bin/fsdctl agent install`（/Library/LaunchDaemons） | 可选；不装就每次手动 start |
| `venv\Scripts\python[w].exe`、`mitmdump.exe` | `venv/bin/python`、`venv/bin/mitmdump` | 一律按 `sys.executable` 推导，不再写死 |
| `requirements.txt`（44 项，含 `pydivert`、`mitmproxy-windows`） | `requirements-mac.txt`（5 项） | Windows 专用包全去掉；macOS 自动装 `mitmproxy-macos` / `mitmproxy_rs` |
| 写死 `C:\fsd-mitm`（约 24 处） | `Path(__file__)` 推导 + `config.json` | 装在哪都能跑；换车换网段只改 config |
| `taskkill` / `netstat -ano` / `ping -n` / `arp -a` GBK | `os.kill` / `lsof` / `ping -c` / `arp -an` | 看板与旧看板已按平台分支 |

---

## 3. 装完先做的三件事

```bash
# ① 填车机与网关（看板 /config 只改载荷，不改网络参数）
~/fsd-mitm/bin/fsdctl config target 192.168.1.50
~/fsd-mitm/bin/fsdctl config gateway 192.168.1.1
~/fsd-mitm/bin/fsdctl config iface en0          # 车机所在网卡；互联网共享时是 bridge100
# 不知道车机 IP？连上设备后扫：
~/fsd-mitm/bin/fsdctl scan

# ② 起全套（DNS 53 / 443 / ARP 都要 root，一条命令搞定）
~/fsd-mitm/bin/fsdctl start

# ③ 自测 + 看板
~/fsd-mitm/bin/fsdctl selftest
open http://127.0.0.1:8900
```

`selftest` 会打印什么（实测输出）：

```
期望 payload: 602 字节 / md5 241cb01b81a2b9c8b9f389a471bcbc94
tls ok: TLSv1.3 | cipher: TLS_AES_256_GCM_SHA384
leaf issuer : CN=EM OV TLS CA - G3C,O=eMudhra Inc,C=US
issuer 匹配: True | 签名有效: True
body bytes: 602  md5: 241cb01b81a2b9c8b9f389a471bcbc94
size match: True | md5 match: True | X-Checksum 正确: True
RESULT: PASS
```

> **为什么本机不校验 emSign 根**：`--emudhra` 的链根是 `emSign ECC Root CA - G3`，
> 它躺在**车机的信任库**里，不在这台 Mac。本机装它没有意义。所以自测只校验
> 「叶证书由 `EM OV TLS CA - G3C` 签发且签名真的对得上」+ 载荷一致。
> 真要把设备侧证书做全，用 `bin/fsdctl ca export` 拿 `device-trust-EMOV-G3C.pem`。

---

## 4. 车机流量怎么到这台 Mac（三种拓扑，选一个）

macOS 上唯一和第 Windows 版有实质差别的地方。

**A. 路由器局域网（最稳）**
车机和 Mac 连同一个 Wi-Fi/路由器，`iface=en0`，`gateway=`路由器 IP，`target=`车机 IP。
ARP 投毒 + DNS 劫持都在这张网卡上做，不碰系统共享。

**B. Mac 开「互联网共享」当热点（最省事，等价 Windows 的 route B）**
1. 系统设置 → 通用 → 共享 → 互联网共享：
   来源选上行（en0 / USB 网卡），去向勾 **Wi-Fi**，Wi-Fi 选项里设 SSID + 密码 → 打开。
2. 车机连这个 SSID，拿到 `192.168.2.x`；本机在 `bridge100` 上是 `192.168.2.1`。
3. 配置：

```bash
~/fsd-mitm/bin/fsdctl config iface bridge100
~/fsd-mitm/bin/fsdctl config gateway 192.168.2.1
~/fsd-mitm/bin/fsdctl config our_ip 192.168.2.1
~/fsd-mitm/bin/fsdctl config answer 192.168.2.1
~/fsd-mitm/bin/fsdctl config target 192.168.2.<车机>   # fsdctl scan 能扫出来
~/fsd-mitm/bin/fsdctl stop && ~/fsd-mitm/bin/fsdctl start
```

`fsdctl doctor` 里的「互联网共享 / bridge100」两行可以确认共享是否真起来了。

**C. USB 网卡 + 手机 USB 共享（Windows 版的 route A 等价物）**
手机 USB 共享给 Mac（出现 `en5/en6…`），车机连手机热点；`iface` 指到 USB 网卡，
`gateway` 是手机的 `192.168.42.129` 之类。看 `ifconfig` 或 `fsdctl doctor` 里的地址列表。

---

## 5. 命中判据（三条都成立才算成功）

1. `logs/hits.jsonl` 新增 `"kind":"HIT"`，且 `"client"` 是**车机 IP**（`127.0.0.1` 是自测，不算）
2. 响应字节数 = `payload.json` 长度（602 B）
3. `logs/requests/*.bin` 里有车机原始请求体

看板 `http://127.0.0.1:8900` 上能直接看到这三样，`fsdctl status` 最后一行是最近一条命中。

```bash
tail -f ~/fsd-mitm/logs/hits.jsonl
tail -f ~/fsd-mitm/logs/arp_mitm.log
ls -l  ~/fsd-mitm/logs/requests/ | tail
```

**改载荷不用重启**：编辑 `payload.json`（或看板 `/payload`、`/config`），`fsd_mock` 按 mtime 热加载。
**只看不回**：`fsdctl mode observe`（车机请求照常走上游，只记录），改回 `fsdctl mode reply`。
**回滚**：`cp payload-282b.json payload.json`（车机侧期望的 282 字节官方形态）。

---

## 6. macOS 专有坑（踩过就写在这）

1. **必须有 root**：UDP 53、TCP 443、scapy 的 `/dev/bpf*` 都要权限。`fsdctl start/stop/stop-api` 会
   自动 `sudo -E` 重跑自己，输一次密码即可。只用 `status/doctor/config/ca/hosts/payload` 不需要 root。
2. **5353 已被 mDNSResponder 占**（Windows 上可以拿 5353 兜底，Mac 上不行）。所以 DNS 只有 53 一条路，
   要么 sudo，要么改 `port_dns`。自测时我用的 5354。
3. **默认路由可能是 `utun*`（VPN 开着）**：`install.sh` 会把 `iface` 落到有私网地址的 `en*`，
   不会跟着默认路由走。`fsdctl doctor` 最后一行会提示。
4. **互联网共享不能脚本开关**：`web/server.py` 的 `POST /api/hotspot/start` 在 macOS 上会返回
   「怎么做」的说明而不是真去开共享。用系统设置手开。
5. **应用防火墙（ALF）**：首次运行会弹「是否允许 python 接受传入连接」→ 允许。若开了
   「阻止所有入站连接」，车机连不进来，`fsdctl pf` 会告诉你当前状态。
6. **不需要 pf rdr**：本方案是 ARP 投毒 + DNS 劫持，车机直接连本机 443/4567，
   所以没有 Windows 那套 `New-NetFirewallRule` 的等价步骤。
7. **换网段/IP 变了**：`stack.py` 会自动用新 IP 重启 DNS sink；但 **ARP 引流要手动重启**
   （`fsdctl stop && fsdctl start`），因为投毒目标/网关是启动时算的。
8. **停了也要还原 ARP**：`arp_mitm.py` 收到 SIGTERM/SIGINT/SIGHUP 会先把车机网关 ARP 改回真实 MAC。
   所以永远用 `fsdctl stop`，不要 `kill -9` 硬杀（硬杀后车机会短时断网，重启车机 Wi-Fi 或等 ARP 老化即可）。
9. **logs 归 root**：root 起的进程写的日志属主是 root。想用编辑器改日志/请求体：
   `sudo chown -R "$(whoami)" ~/fsd-mitm/logs`。
10. **Python 必须是 3.12+**：`/usr/bin/python3` 是 3.9，装不了 mitmproxy 12。安装器会自动挑
    Homebrew 的 3.13/3.12，找不到就报错让你 `brew install python@3.13`。
11. **看门狗 + launchd 别叠加**：`fsdctl agent install` 之后 launchd 用 `KeepAlive` 拉起看门狗，
    看门狗再拉各组件；这时不要再手动 `fsdctl start`（会重复）。两者选一。
12. **443 只有一个进程能用**：旧看板/自测用完记得 `fsdctl stop`，否则 `start` 会认为「已在运行」。
13. **`nohup` 在无 tty 的 root 环境里是坏的**：BSD `nohup` 会直接报
    `can't detach from console: No such process` 并且**不启动进程**。
    从 AppleScript（`do shell script ... with administrator privileges`）、launchd、
    无 tty 的 ssh 里跑 `start` 全中。所以 Mac 版一律用 `tools/daemonize.py`
    （`start_new_session=True`）后台化，`fsdctl` 里已经不含 `nohup`。
14. **SIGTERM 会被"继承为忽略"或"继承为屏蔽"**：AppleScript/launchd 的 shell 会把
    SIGTERM 设成 `SIG_IGN`，或者放进 `sigprocmask` 屏蔽字；**exec 不会清这两样**。
    症状：`fsdctl stop` 打印「已停」，端口却还在、进程还在，最后只能 SIGKILL。
    修法写在 `reset_signals()`：既 `signal(SIGTERM, SIG_DFL)` 又
    `pthread_sigmask(SIG_UNBLOCK)`，`daemonize.py` / `stack.py` / `supervise_all.py`
    三处都做，子进程再 fork 出来就是干净的默认处置。
15. **`pgrep -f "xxx.py"` 会误杀**：任何命令行里含这个字符串的进程都会被匹配
    —— 包括正在 `grep xxx.py` 的 shell、开着该文件的编辑器、甚至调用 `fsdctl` 的宿主
    （实测把发起本次命令的 shell 自己 SIGTERM 掉了）。Mac 版的判据是
    「命令行里必须有 `<安装目录>/` 绝对路径 **且** 第一个 token 是本环境的 python/mitmdump」，
    最终兜底交给 `tools/reap.py`（先 TERM，4 秒后对残留 KILL）。
16. **非 root 的 `lsof` 看不到 root 进程的监听**：`fsdctl status` 的 pid 列会空着，
    但端口状态用的是 `nc -z`，仍然准确；要看 pid 就 `sudo fsdctl status`。

---

## 7. 完整命令表

```bash
fsdctl start [--no-arp|--no-supervise]   # 起全套（幂等）
fsdctl stop                              # 全停（含看门狗；先还原 ARP）
fsdctl stop-api                          # 只撤 api-prd 拦截
fsdctl status                            # 9 项状态 + 最近命中
fsdctl doctor                            # 体检：网卡/权限/端口/依赖/证书/共享
fsdctl selftest [--anchor certs2/device-trust-EMOV-G3C.pem]   # 自测
fsdctl scan                              # 局域网找车机
fsdctl config                            # 打印配置
fsdctl config <key> <value>              # 改配置（stop+start 生效）
fsdctl config edit                       # 手改 config.json
fsdctl ca list|install|uninstall|export  # 证书：看/装本机钥匙串/卸/导出设备信任
fsdctl hosts show|add|remove             # /etc/hosts 劫持
fsdctl pf                                # macOS 防火墙与 pf 现状 + 建议
fsdctl agent install|uninstall|status    # 开机自启（launchd）
fsdctl payload show|edit                 # 载荷（热加载）
fsdctl mode reply|observe                # 短路回包 / 只看不回
fsdctl logs [name]                       # tail 日志（默认 stack.log）
fsdctl arp [--dry-run]                   # 只起 ARP 引流；--dry-run 只校验网卡/MAC，不发包
fsdctl diag [--short]                    # 一次性诊断报告（贴给人就能定位，见第 9 节）
```

别名：`echo 'alias fsdctl="$HOME/fsd-mitm/bin/fsdctl"' >> ~/.zshrc`

---

## 8. 本次移植实测记录（2026-11-20，macOS 27.3 / arm64）

| 项目 | 结果 |
|---|---|
| `install.sh` 全流程 | 通过，venv + 5 个顶层依赖（mitmproxy 12.3.1 / scapy 2.8.0 / flask 3.1.3 / cryptography 50.0.2） |
| `mitmdump --emudhra` 在 macOS | 可用，TLSv1.3，叶证书由 `EM OV TLS CA - G3C` 签发，签名经 `verify_directly_issued_by` 验证通过 |
| `fsd_mock` 短路 | 通过：602 B + `X-Checksum: 241cb01b…`，`logs/hits.jsonl` / `logs/requests/*.bin` 落盘正常 |
| `svc/stack.py`（非 root） | reverse 4567 / proxy 8080 / 旧看板 8899 全部拉起；DNS 正确报 `need_root` |
| `dns_sink.py` | 通过：`mothership.vn.teslamotors.com` → 本机 IP（5354 实测；53 需 sudo） |
| `fsd_panel.py` 8900 | 通过：`/`、`/config`、`/api/state` 均 200，服务端渲染无 JS |
| `fsdctl stop` | 通过：无残留进程，端口全释放 |
| `bin/fsdctl start`（root 全进程） | 通过（GUI 授权执行）：栈/443/8900/53/看门狗全 OK |
| **443 反代真实拦截** | 通过：`POST /mothership/vehicles/LRWTEST0002/feature_configuration` → HTTP/2 200、602 B、`x-checksum` 一致，请求体 35 B 落盘 `logs/requests/` |
| **DNS 53 劫持** | 通过：从局域网地址 `@192.168.0.178` 查 `mothership.*` / `api-prd.*` 均答 `192.168.0.178`；回环查询答 `127.0.0.1`（按对端网段自动选，符合设计） |
| **ARP 链路（root）** | 通过（`--dry-run`，不发包）：网卡 `en0`、本机 MAC、车机/网关 MAC 解析、投毒帧、嗅探过滤、RST 目标全部正确构造 |
| `bin/fsdctl stop` | 通过：8 个进程全部 TERM 正常退出（不再升级 SIGKILL），`reap.py` 复核「没有残留」，6 个端口全释放 |

> 唯一没做的是**真的往车机上打**：那需要车机在线 + `target` 填成车机 IP。
> 网络侧（DNS/443/ARP 帧）都已在你这台机器上逐段验证过。

> 上车前建议先跑 `sudo bin/fsdctl start`，然后盯着
> `logs/arp_mitm.log` 里有没有 `TLS ClientHello SNI=mothership.*` 和 `*** 命中目标域名 ***`
> —— 这一行出现，才说明车机真把流量送过来了。


---

## 9. 实机排查：`fsdctl diag`

别人机器上跑起来"看着没命中"时，先跑这一条，把输出贴出来就够定位：

```bash
~/fsd-mitm/bin/fsdctl diag
```

它一次性回答四个问题：

1. **车机到底有没有连到我们**：DNS 重定向条数里有多少来自车机网段、TLS 成功/失败各几次（区分车机侧与回环）
2. **它请求了哪些 host / path**：出现过的 `host+path` 次数排行，以及最近 15 条的 `client`
3. **为什么没命中**：`feature_configuration` 出现过没有、`mode` 是不是 `observe`
4. 载荷字节/md5、6 个端口谁在听

结尾会直接打「结论 · ...」，例如：

- `车机流量到了，但从没请求过 feature_configuration` → 不是拦截坏了，是车机还没到拉配置的动作（重启车机 / 关开 Wi-Fi / 等它下一次轮询）
- `mode=observe` → 只记录不回包，`fsdctl mode reply`
- `有 N 次车机侧握手失败` → 它不信任 emSign 链；改走 4567 明文反向（DNS 劫持 mothership.*）就不依赖证书

### 两种"看着像坏了"的假象（已在 2026-11-20 修）

| 假象 | 真相 |
|---|---|
| 看板「握手失败」成片 | 多数是**端口探活/非 TLS 连接**（客户端是 `::1` / `127.0.0.1`、SNI 空、error `None`）。现在这类记成 `probe_non_tls`，面板单独标「探活/非TLS」，不再混进握手失败 |
| 看板「车机请求总数」显示 `%d` | 模板格式化 bug（`%` 只作用到后面那条拼接串），已改为直接取 `car_requests` |

### 上游黑洞的影响

`svc/stack.py` 的 4567 反向用的是 `reverse:http://192.0.2.1:4567`（和 Windows 版一致）：
**命中路径之外的 mothership 请求会被黑洞**（车机看到 502/超时）。这在原包里是已验证配置，
但如果车机因为业务接口报错而推迟拉配置，把 `config.json` 的

```json
"reverse_upstream": "192.0.2.1"
```

改成真实上游 IP（旧看板 `web/server.py` 里用 `dig` 解出来的那个），其余放行、只拦配置。

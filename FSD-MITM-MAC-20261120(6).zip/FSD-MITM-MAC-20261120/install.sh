#!/bin/bash
# install.sh — FSD 拦截环境 · macOS 安装器
#              等价 Windows 版 install.ps1 的 7 步，去掉 UAC/注册表/快捷方式，
#              换成 venv + /Library/LaunchDaemons（可选）+ 钥匙串证书。
#
#   ./install.sh                 装到 ~/fsd-mitm 并自检（不自动启动）
#   ./install.sh --start         装完直接起全套（会要 sudo）
#   ./install.sh --home ~/fsd    换安装目录
#   ./install.sh --mirror        pip 走清华源
#   ./install.sh --check         只体检，不动文件
#   ./install.sh --force         目标已存在时强制覆盖程序（保留 logs/venv/payload 改动）
#   ./install.sh --python /opt/homebrew/bin/python3.13

set -uo pipefail

PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOME_DIR="$HOME/fsd-mitm"
MIRROR=0
DO_START=0
CHECK_ONLY=0
FORCE=0
PYBIN=""

while [ $# -gt 0 ]; do
  case "$1" in
    --home) HOME_DIR="${2:?}"; shift 2 ;;
    --mirror) MIRROR=1; shift ;;
    --start) DO_START=1; shift ;;
    --check) CHECK_ONLY=1; shift ;;
    --force) FORCE=1; shift ;;
    --python) PYBIN="${2:?}"; shift 2 ;;
    -h|--help) sed -n '2,14p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "未知参数: $1"; exit 2 ;;
  esac
done

C_OK=$'\033[32m'; C_BAD=$'\033[31m'; C_WARN=$'\033[33m'; C_DIM=$'\033[2m'; C_END=$'\033[0m'
ok()   { printf '%s%s%s\n' "$C_OK" "$*" "$C_END"; }
bad()  { printf '%s%s%s\n' "$C_BAD" "$*" "$C_END"; }
warn() { printf '%s%s%s\n' "$C_WARN" "$*" "$C_END"; }
dim()  { printf '%s%s%s\n' "$C_DIM" "$*" "$C_END"; }
step() { printf '\n\033[1m[%s/7] %s\033[0m\n' "$1" "$2"; }

# ---------------------------------------------------------------- 0) 体检
step 0 "环境检查"
[ "$(uname -s)" = "Darwin" ] || { bad "这不是 macOS"; exit 1; }
ok "macOS $(sw_vers -productVersion) / $(uname -m)"
[ "$(uname -m)" = "arm64" ] && dim "  Apple Silicon：venv 会用原生 arm64 轮子" || dim "  Intel：pip 会取 x86_64 轮子"

if [ -z "$PYBIN" ]; then
  for c in /opt/homebrew/bin/python3.13 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.13 \
           /usr/local/bin/python3.12 "$(command -v python3.13 2>/dev/null)" "$(command -v python3.12 2>/dev/null)" \
           "$(command -v python3 2>/dev/null)"; do
    [ -n "${c:-}" ] && [ -x "$c" ] || continue
    v="$("$c" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)"
    case "$v" in 3.12|3.13|3.14) PYBIN="$c"; break ;; esac
  done
fi
[ -n "$PYBIN" ] || { bad "找不到 Python 3.12+：brew install python@3.13，或用 --python 指定"; exit 1; }
ok "Python: $PYBIN ($("$PYBIN" -V 2>&1))"
dim "  /usr/bin/python3 是 3.9（系统自带），装不了 mitmproxy 12 → 已跳过"

if [ "$CHECK_ONLY" = 1 ]; then
  echo
  dim "检查模式：什么都没改。"
  dim "iface 建议值："
  for d in $(networksetup -listallhardwareports 2>/dev/null | awk '/Device:/{print $2}'); do
    ip="$(ipconfig getifaddr "$d" 2>/dev/null)"
    [ -n "$ip" ] && printf '  %-8s %s\n' "$d" "$ip"
  done
  exit 0
fi

# ---------------------------------------------------------------- 1) 目录
step 1 "目录检查 → $HOME_DIR"
if [ -e "$HOME_DIR/fsd_mock.py" ] && [ "$FORCE" != 1 ]; then
  warn "  $HOME_DIR 已有部署：只更新程序，保留 logs/ venv/ config.json payload.json"
fi
mkdir -p "$HOME_DIR" "$HOME_DIR/logs"
ok "目录就绪"

# ---------------------------------------------------------------- 2) 复制程序
step 2 "复制程序（包根 → $HOME_DIR 平铺，与 Windows 的 C:\\fsd-mitm 同构）"
[ -f "$HOME_DIR/payload.json" ] && cp "$HOME_DIR/payload.json" "$HOME_DIR/payload.json.preinstall-$(date +%Y%m%d%H%M%S)"
rsync -a \
      --exclude 'venv' --exclude 'logs' --exclude 'config.json' --exclude '.git' \
      --exclude 'payload.json' --exclude 'mode.json' --exclude '__pycache__' \
      --exclude 'install.sh' --exclude 'README.md' --exclude 'device' \
      "$PKG/" "$HOME_DIR/" 2>/dev/null || {
        cd "$PKG" && tar cf - --exclude venv --exclude logs --exclude .git . | (cd "$HOME_DIR" && tar xf -); }
# payload：已经部署过就用已有的（避免覆盖用户改过的载荷）
if [ ! -f "$HOME_DIR/payload.json" ]; then cp "$PKG/payload.json" "$HOME_DIR/payload.json"; fi
[ -f "$HOME_DIR/mode.json" ] || printf '{"mode": "reply"}\n' > "$HOME_DIR/mode.json"
chmod +x "$HOME_DIR/bin/fsdctl"
ok "$(find "$HOME_DIR" -type f -not -path '*/venv/*' -not -path '*/logs/*' | wc -l | tr -d ' ') 个程序文件就位"

# ---------------------------------------------------------------- 3) venv
step 3 "虚拟环境 + 依赖"
if [ ! -x "$HOME_DIR/venv/bin/python" ]; then
  "$PYBIN" -m venv "$HOME_DIR/venv" || { bad "venv 创建失败"; exit 1; }
  ok "已建 venv"
else
  dim "  复用已有 venv：$("$HOME_DIR/venv/bin/python" -V 2>&1)"
fi
PIP="$HOME_DIR/venv/bin/pip"
"$PIP" install -q --upgrade pip >/dev/null 2>&1
PIPARGS=(-q -r "$PKG/requirements-mac.txt")
[ "$MIRROR" = 1 ] && PIPARGS=(-q -r "$PKG/requirements-mac.txt" -i https://pypi.tuna.tsinghua.edu.cn/simple)
say_progress() { printf '  安装 mitmproxy 12.3.1 / scapy / flask …（首次约 1-2 分钟）\n'; }
say_progress
if ! "$PIP" install "${PIPARGS[@]}"; then
  warn "  pin 版本装不上，退回不锁定版本再试一次"
  "$PIP" install -q mitmproxy scapy flask || { bad "依赖安装失败"; exit 1; }
fi
ok "依赖就绪：$("$HOME_DIR/venv/bin/python" -c 'from importlib.metadata import version as v;print("mitmproxy",v("mitmproxy"),"scapy",v("scapy"),"flask",v("flask"))')"

# ---------------------------------------------------------------- 4) config
step 4 "生成 config.json（自动探测网卡/网关）"
if [ -f "$HOME_DIR/config.json" ]; then
  dim "  已存在，保留（查看：$HOME_DIR/bin/fsdctl config）"
else
  # 选 iface：优先硬件端口叫 Wi-Fi 且拿到私网地址的，其次第一个有私网地址的 en*
  IFACE=""; OUR_IP=""
  for d in $(networksetup -listallhardwareports 2>/dev/null | awk '/Device:/{print $2}'); do
    ip="$(ipconfig getifaddr "$d" 2>/dev/null)" || continue
    [ -n "$ip" ] || continue
    case "$ip" in 192.168.*|10.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*) ;; *) continue ;; esac
    IFACE="$d"; OUR_IP="$ip"
    networksetup -listallhardwareports | grep -A2 "Device: $d" | grep -q "Wi-Fi" && break
  done
  [ -z "$IFACE" ] && { IFACE="en0"; OUR_IP="$(ipconfig getifaddr en0 2>/dev/null || echo '')"; }
  GW="$(ipconfig getoption "$IFACE" router 2>/dev/null || echo '')"
  "$HOME_DIR/venv/bin/python" - "$PKG/config.json" "$HOME_DIR/config.json" "$IFACE" "$OUR_IP" "$GW" <<'EOF'
import json, sys
src, dst, iface, ip, gw = sys.argv[1:6]
cfg = json.load(open(src, encoding="utf-8"))
cfg["iface"] = iface or "en0"
cfg["our_ip"] = ip
cfg["answer"] = ip
cfg["gateway"] = gw
json.dump(cfg, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(f"  iface={cfg['iface']} our_ip={ip or '(空)'} gateway={gw or '(空)'} target=(待填)")
EOF
  ok "已写 $HOME_DIR/config.json"
fi

# ---------------------------------------------------------------- 5) 文件体检
step 5 "文件体检"
miss=0
for f in fsd_mock.py fsdconfig.py dns_sink.py svc/stack.py tools/arp_mitm.py \
         tools/supervise_all.py web/fsd_panel.py web/server.py payload.json \
         mode.json certs2/mitmproxy-ca.pem bin/fsdctl; do
  [ -e "$HOME_DIR/$f" ] || { bad "  缺 $f"; miss=1; }
done
"$HOME_DIR/venv/bin/python" - "$HOME_DIR" <<'EOF' || miss=1
import json, sys, os
root = sys.argv[1]
for name in ("config.json", "payload.json"):
    p = os.path.join(root, name)
    try:
        json.load(open(p, encoding="utf-8")); print(f"  {name} 合法")
    except Exception as e:
        print(f"  {name} 解析失败:", e); raise SystemExit(1)
EOF
[ "$miss" = 0 ] && ok "体检通过（10 项关键文件 + config/payload 合法性）" || warn "有缺失项，见上"

# ---------------------------------------------------------------- 6) 自启
step 6 "开机自启（可选）"
dim "  需要的话：sudo $HOME_DIR/bin/fsdctl agent install   （等价 Windows 的 HKCU Run → 看门狗）"
dim "  不要就跳过，每次手动 bin/fsdctl start"

# ---------------------------------------------------------------- 7) 完成
step 7 "完成"
cat <<EOF

  安装目录   $HOME_DIR
  配置       $HOME_DIR/config.json
  看板       http://127.0.0.1:8900   （配置页 /config）
  日志       $HOME_DIR/logs/

  下一步（按顺序）：
    1) 把车机 IP / 网关填进配置（看板 /config 只改载荷，不改网络参数）：
         $HOME_DIR/bin/fsdctl config target 192.168.1.50
         $HOME_DIR/bin/fsdctl config gateway 192.168.1.1
       或者插上设备先扫一遍：
         $HOME_DIR/bin/fsdctl scan
    2) 起全套（会要一次 sudo 密码）：
         $HOME_DIR/bin/fsdctl start
    3) 体检 / 状态：
         $HOME_DIR/bin/fsdctl doctor
         $HOME_DIR/bin/fsdctl status
    4) 全停（会先还原车机 ARP）：
         $HOME_DIR/bin/fsdctl stop

  加个快捷方式到终端 PATH（可选）：
         echo 'alias fsdctl="$HOME_DIR/bin/fsdctl"' >> ~/.zshrc

EOF
if [ "$DO_START" = 1 ]; then
  say_progress() { :; }
  sudo -E "$HOME_DIR/bin/fsdctl" start
fi

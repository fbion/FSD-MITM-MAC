"""fsdconfig.py — 运行配置（config.json）的唯一读取点（macOS 版新增）

Windows 版把车机 IP / 网关 / 网卡名写死在 start_all.ps1、supervise_all.py、
stop_api_intercept.ps1 里，换车换网段要改四个文件。Mac 版统一收口到
`<ROOT>/config.json`，所有脚本只读这里。

查找顺序：
  1) 环境变量 FSD_CONFIG 指向的文件
  2) <ROOT>/config.json
  3) 内置默认值

`app/bin/fsdctl` 用 shell 读同一个文件（用 python 打印），保证两边一致。
"""
from __future__ import annotations

import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent

DEFAULTS: dict = {
    # ---- 拓扑 ----
    "iface": "en0",              # 车机所在网卡（Wi-Fi 一般是 en0；Internet Sharing 用 bridge100）
    "target": "",                # 车机 IP
    "gateway": "",               # 车机侧的网关 IP（热点网关/路由器）
    "our_ip": "",                # 本机在车机网段的 IP（空=自动探测 iface 地址）
    "answer": "",                # DNS 应答里给的 IP（空=跟 our_ip 一致）
    "upstream_dns": "223.5.5.5,1.1.1.1",
    "redirect": [                # 要劫持到本机的域名
        "mothership.vn.teslamotors.com",
        "mothership.vn.cloud.tesla.cn",
        "api-prd.vn.cloud.tesla.cn",
    ],
    "rst_dst": "52.81.9.181",    # 对这些目的 IP 直接 RST（车机 443 直连黑洞，逼它走本机）
    "no_api": False,             # true = 不劫持 api-prd（= 一行 stop-api）
    # ---- 端口 ----
    "port_dns": 53,
    "port_reverse": 4567,
    "port_proxy": 8080,
    "port_api": 443,
    "port_panel": 8900,
    "port_legacy": 8899,
    # ---- 行为 ----
    "confdir": "certs2",
    "duration": 0,               # 0 = 一直跑
    "autostart_agent": False,
    # car_ip_for_panel 由 target 派生，不在文件里
}


def path() -> Path:
    env = os.environ.get("FSD_CONFIG")
    if env:
        return Path(env)
    return ROOT / "config.json"


def load() -> dict:
    cfg = dict(DEFAULTS)
    p = path()
    try:
        with open(p, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            cfg.update({k: v for k, v in data.items() if not k.startswith("_")})
    except (OSError, ValueError):
        pass
    # 归一化
    for k in ("target", "gateway", "our_ip", "answer", "iface", "rst_dst", "upstream_dns"):
        if cfg.get(k) is None:
            cfg[k] = ""
    if not cfg.get("answer"):
        cfg["answer"] = cfg.get("our_ip") or ""
    # 看板里标"车机"的 IP 恒等于 target（派生，不落盘）
    cfg["car_ip_for_panel"] = cfg.get("target") or ""
    if isinstance(cfg.get("redirect"), str):
        cfg["redirect"] = [x.strip() for x in cfg["redirect"].split(",") if x.strip()]
    return cfg


def save(cfg: dict) -> None:
    """写回 config.json。

    派生键不落盘：`car_ip_for_panel` 默认跟随 target，写死会把旧 target 残留下来
    （改 target 后看板还显示上一台车）。注释键 `_*` 也不写。
    """
    out = {k: v for k, v in cfg.items() if not k.startswith("_")}
    out.pop("car_ip_for_panel", None)   # 派生键，永远不写
    p = path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
        fh.write("\n")


def get(key: str):
    return load().get(key, DEFAULTS.get(key))


if __name__ == "__main__":
    import sys

    cfg = load()
    if len(sys.argv) == 1:
        print(json.dumps(cfg, ensure_ascii=False, indent=2))
    else:
        print(cfg.get(sys.argv[1], ""))
